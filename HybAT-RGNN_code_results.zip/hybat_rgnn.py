# -*- coding: utf-8 -*-
"""
hybat_rgnn.py -- HybAT-RGNN: trust-aware federated cyberthreat detection on Edge-IIoTset
(hybrid PGD/FGSM adversarial training, CNN-GRU classifier, RNN + GNN trust estimation with MC-dropout
uncertainty, NE-AGVO trust-weighted aggregation).

Setup: 12 classes (first 5,000 records per class of DNN-EdgeIIoT-dataset.csv), stratified 70:30 split,
12 IID clients, clients 1 and 2 malicious (sign-flipping), 20 rounds, 1 local epoch, batch 64,
Adam 1e-3, seed 42. Everything (data, model, local training, evaluation) is identical to baselines.py;
only the server-side aggregation differs.

Notes on the implementation (corrections of the first notebook version):
  * Trust RNN is trained with binary cross-entropy towards the consensus of each client's update with the
    other clients, (1 + mean cosine similarity) / 2.
  * NE-AGVO accepts a candidate only if its own fitness  trust.w - 0.1*diversity(w)  is higher.
  * GNN trust is min-max normalised to [0, 1].

Run (same folder as DNN-EdgeIIoT-dataset.csv):
    python hybat_rgnn.py --quick     (3-minute test)
    python hybat_rgnn.py             (full run, ~1.8 h on a Core i5 CPU)
Results: folder results/HybAT-RGNN
"""
# ---- CELL 1
import pandas as pd
import warnings
from sklearn.preprocessing import StandardScaler, label_binarize
from sklearn.model_selection import train_test_split
from keras.utils import to_categorical
import numpy as np
import random
from keras import layers, models, optimizers
import os
import matplotlib.pyplot as plt
import seaborn as sbn
from sklearn.metrics import (
    confusion_matrix, accuracy_score, precision_score, f1_score,
    matthews_corrcoef, recall_score, roc_curve, roc_auc_score, auc,
    precision_recall_curve, average_precision_score
)
import tensorflow as tf
from tqdm import tqdm

warnings.filterwarnings("ignore")
plt.rcParams['font.family'] = 'Consolas'
# ---- CELL 2
# ---------------- CONFIG ----------------
SEED = 42
random.seed(SEED)
np.random.seed(SEED)
tf.random.set_seed(SEED)

OUTPUT_DIR = "results"
os.makedirs(OUTPUT_DIR, exist_ok=True)

N_CLIENTS = 12
ROUNDS = 20
LOCAL_EPOCHS = 1
BATCH_SIZE = 64
LEARNING_RATE = 1e-3

n_classes = 12

import sys
QUICK = "--quick" in sys.argv          # smoke test: 2 rounds, 300 records per class (a few minutes)
PER_CLASS = 300 if QUICK else 5000
if QUICK:
    ROUNDS = 2
    OUTPUT_DIR = "results_quick_test"
    import shutil; shutil.rmtree(OUTPUT_DIR, ignore_errors=True)    # quick test always starts fresh
    os.makedirs(OUTPUT_DIR, exist_ok=True)
# ---- CELL 3
CLASSES = [
    "Normal",
    "DDoS-UDP",
    "DDoS-ICMP",
    "SQL injection",
    "DDoS-TCP",
    "Password",
    "DDoS-HTTP",
    "Uploading",
    "Backdoor",
    "XSS",
    "Ransomware",
    "Fingerprinting",
]
# ---- CELL 4
df = pd.read_csv("DNN-EdgeIIoT-dataset.csv", low_memory=False)
N_RAW = len(df)
df.dropna(inplace=True)
N_AFTER_DROPNA = len(df)
df.drop(["frame.time", "Attack_label"], axis=1, inplace=True)
df.columns = df.columns.tolist()[:-1] + ["class"]

df["class"] = df['class'].replace(
    {
        "DDoS_UDP": "DDoS-UDP",
        "DDoS_ICMP": "DDoS-ICMP",
        "SQL_injection": "SQL injection",
        "DDoS_TCP": "DDoS-TCP",
        "DDoS_HTTP": "DDoS-HTTP",
    },
)

dfs = []
for c in CLASSES:
    dfs.append(df[df["class"] == c].head(PER_CLASS))
df = pd.concat(dfs)
for c in df.columns:
    try:
        df[c] = df[c].astype(float)
    except:
        pass

df
# ---- CELL 5
def replace_categorical_cols(df):
    for col in df.columns:
        if col == "class":
            continue
        if df[col].dtype not in ["object", 'str']:
            continue
        print(col, df[col].dtype)
        # print("[INFO] Replacing Categorical Values in Column :: {0}".format(col))
        repd = {v: k + 1 for k, v in enumerate(sorted(df[col].unique()))}
        df[col] = df[col].replace(repd).astype(int)
    df.reset_index(drop=True, inplace=True)
    return df
# ---- CELL 6
df["class"] = df["class"].replace({CLASSES[i]: i for i in range(len(CLASSES))}).astype(int)
df = replace_categorical_cols(df)
df.to_csv(os.path.join(OUTPUT_DIR, "preprocessed.csv"), index=False)
df
# ---- CELL 7
df = pd.read_csv(os.path.join(OUTPUT_DIR, "preprocessed.csv"))
X, y = df.values[:, :-1], df.values[:, -1]
scaler = StandardScaler()
X = scaler.fit_transform(X)
y_cat = to_categorical(y, len(CLASSES))
X_train, X_test, y_train, y_test = train_test_split(
    X, y_cat, test_size=0.3, stratify=y, random_state=42
)
input_dim = X_train.shape[1]
print(f"[INFO] Train Data Shape :: {X_train.shape}")
print(f"[INFO] Train Label Shape :: {y_train.shape}")
print(f"[INFO] Test Data Shape :: {X_test.shape}")
print(f"[INFO] Test Label Shape :: {y_test.shape}")
# ---- CELL 8
# ---------------- FeaturePad Layer ----------------
class FeaturePad(layers.Layer):
    def __init__(self, pad_size=0):
        super().__init__()
        self.pad_size = int(pad_size)

    def call(self, inputs):
        if self.pad_size <= 0:
            return inputs
        return tf.pad(inputs, [[0, 0], [0, self.pad_size]], "CONSTANT")


# ---------------- PGD Adversarial Attack ----------------
def pgd_batch_tf(model, x_batch, y_batch, eps=0.01, alpha=0.005, steps=3):
    orig = x_batch.astype(np.float32)
    adv = orig.copy()
    for _ in range(steps):
        x = tf.convert_to_tensor(adv, dtype=tf.float32)
        y = tf.convert_to_tensor(y_batch, dtype=tf.float32)
        with tf.GradientTape() as tape:
            tape.watch(x)
            logits = model(x, training=False)
            loss = tf.keras.losses.categorical_crossentropy(y, logits)
        grad = tape.gradient(loss, x).numpy()
        adv = adv + alpha * np.sign(grad)
        adv = np.clip(adv, orig - eps, orig + eps)
    return adv


# ---------------- FGSM Adversarial Attack ----------------
def fgsm_batch_tf(model, x_batch, y_batch, eps=0.01):
    x = tf.convert_to_tensor(x_batch, dtype=tf.float32)
    y = tf.convert_to_tensor(y_batch, dtype=tf.float32)

    with tf.GradientTape() as tape:
        tape.watch(x)
        preds = model(x, training=False)
        loss = tf.keras.losses.categorical_crossentropy(y, preds)

    grad = tape.gradient(loss, x)
    adv = x + eps * tf.sign(grad)
    return adv.numpy()


# ---------------- Model builder ----------------
def build_model(input_dim, n_classes, seq_len=8):
    inp = layers.Input(shape=(input_dim,), dtype=tf.float32)
    pad = (seq_len - input_dim % seq_len) % seq_len
    x = FeaturePad(pad)(inp)
    feat = (input_dim + pad) // seq_len
    x = layers.Reshape((seq_len, feat))(x)

    x = layers.Conv1D(32, 3, padding="same", activation="relu")(x)
    x = layers.BatchNormalization()(x)
    x = layers.Conv1D(32, 3, padding="same", activation="relu")(x)
    x = layers.BatchNormalization()(x)
    x = layers.GRU(64)(x)
    x = layers.Dense(64, activation="relu")(x)
    x = layers.Dropout(0.3)(x, training=True)  # key for uncertainty

    out = layers.Dense(n_classes, activation="softmax")(x)

    model = models.Model(inp, out)
    model.compile(
        optimizer=optimizers.Adam(LEARNING_RATE),
        loss="categorical_crossentropy",
        metrics=["accuracy"],
    )
    return model


def mc_dropout_uncertainty(model, X, T=5):
    preds = []
    for _ in range(T):
        preds.append(model(X, training=True).numpy())
    preds = np.array(preds)
    variance = preds.var(axis=0).mean(axis=1)
    return variance


# ------------- Trust RNN Builder --------------
def build_trust_rnn():
    model = tf.keras.Sequential(
        [
            tf.keras.layers.GRU(32, return_sequences=True),
            tf.keras.layers.GRU(16),
            tf.keras.layers.Dense(1, activation="sigmoid"),
        ]
    )
    model.compile(
        optimizer=optimizers.Adam(LEARNING_RATE),
        loss="binary_crossentropy",                       # FIX 1 (was categorical_crossentropy -> loss 0)
        metrics=["accuracy"],
    )
    return model


# trust_rnn is created per method in fresh_start()


def rl_weight_policy(trust, updates):
    mags = np.array([np.linalg.norm(u) for u in updates])
    weights = trust / (mags + 1e-6)
    weights = np.clip(weights, 0, None)
    return weights / (weights.sum() + 1e-8)


# ----------- GNN Adjacency Matrix -------------
def cosine_sim(a, b):
    return np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b) + 1e-8)


def build_adj_matrix(updates):
    n = len(updates)
    A = np.zeros((n, n))
    for i in range(n):
        for j in range(n):
            A[i, j] = cosine_sim(updates[i], updates[j])
    return A


# ---------------- Flatten / Unflatten ----------------
def flatten_weights(weights):
    flat = np.concatenate([w.flatten() for w in weights]).astype(np.float32)
    shapes = [w.shape for w in weights]
    sizes = [w.size for w in weights]
    return flat, shapes, sizes


def unflatten_weights(vec, shapes, sizes):
    out, idx = [], 0
    for s, sz in zip(shapes, sizes):
        out.append(vec[idx : idx + sz].reshape(s))
        idx += sz
    return out


# -------------- AGVO ---------------
def NE_AGVO(updates, trust, iters=50):
    n = len(updates)
    w = np.random.rand(n)
    w = w / w.sum()

    fitness_log = []

    for _ in range(iters):
        agg = np.sum([w[i] * updates[i] for i in range(n)], axis=0)
        diversity = np.mean([np.linalg.norm(agg - updates[i]) for i in range(n)])
        fitness = trust @ w - 0.1 * diversity

        fitness_log.append(fitness)

        # mutation
        w_new = w + 0.02 * np.random.randn(n)

        # crossover
        mask = np.random.rand(n) > 0.5
        w_new[mask] = w[mask]

        w_new = np.clip(w_new, 0, 1)
        w_new = w_new / (w_new.sum() + 1e-8)

        agg_new = np.sum([w_new[i] * updates[i] for i in range(n)], axis=0)          # FIX 2
        fitness_new = trust @ w_new - 0.1 * np.mean([np.linalg.norm(agg_new - updates[i]) for i in range(n)])
        if fitness_new > fitness:
            w = w_new

    return w, fitness_log


# ---------------- Client ----------------
class Client:
    def __init__(self, cid, X, y, model_builder, n_classes):
        self.cid = cid
        self.X = X
        self.y = y
        self.model_builder = model_builder
        self.n_classes = n_classes
        self.history = []

    def local_train(self, global_flat, shapes, sizes):
        self.model = self.model_builder()
        self.model.set_weights(unflatten_weights(global_flat, shapes, sizes))

        Xloc, yloc = np.copy(self.X), np.copy(self.y)
        prev_w = global_flat.copy()

        for _ in range(LOCAL_EPOCHS):
            idx = np.arange(len(Xloc))
            np.random.shuffle(idx)
            for i in range(0, len(idx), BATCH_SIZE):
                b = idx[i : i + BATCH_SIZE]
                xb, yb = Xloc[b], yloc[b]
                adv_pgd = pgd_batch_tf(self.model, xb, yb)
                adv_fgsm = fgsm_batch_tf(self.model, xb, yb)

                X_comb = np.vstack([xb, adv_pgd, adv_fgsm])
                Y_comb = np.vstack([yb, yb, yb])

                self.model.train_on_batch(X_comb, Y_comb)

        new_flat, _, _ = flatten_weights(self.model.get_weights())
        delta = new_flat - prev_w

        # ---- behavior features ----
        grad_norm = np.linalg.norm(delta)
        update_mean = np.mean(delta)
        update_var = np.var(delta)

        self.history.append([grad_norm, update_mean, update_var])

        return delta
# =====================================================================================================
# ADDED: logging, comparison methods, resume
# =====================================================================================================
import sys, time, json, pickle, platform
from sklearn.metrics import classification_report
try:
    import psutil
    PROC = psutil.Process()
    def rss_mb(): return PROC.memory_info().rss / 2**20
except Exception:
    psutil = None
    def rss_mb(): return float("nan")

METHODS = ["HybAT-RGNN"]
MALICIOUS = [0, 1]                       # same as the original notebook (sign-flip attack)
EPS_VALS = [0.0, 0.005, 0.01, 0.02, 0.03]

# Trust-FedGNN (Reis, 2026): reliability R = clip(b1*exp(-d) + b2*psi, 0, 1), trust EMA, weights ~ trust
TFG_ALPHA, TFG_B1, TFG_B2, TFG_T0 = 0.8, 2.0, 1.2, 0.5
# HyperTrust-Fog (Abbas & Albathan, 2026), TAFA: gamma = l1*tau + l2*R + l3*C, weights ~ n_i * gamma_i
HTF_L1, HTF_L2, HTF_L3, HTF_ETA = 0.4, 0.3, 0.3, 0.3
REF_SIZE = 1000                          # server reference samples (Trust-FedGNN accuracy term)


def compute_metrics(y_true, y_prob):
    yt = np.argmax(y_true, axis=1)
    yp = np.argmax(y_prob, axis=1)
    ybin = label_binarize(yt, classes=np.arange(n_classes))
    return {
        "accuracy": accuracy_score(yt, yp),
        "precision": precision_score(yt, yp, average="macro"),
        "recall": recall_score(yt, yp, average="macro"),
        "f1": f1_score(yt, yp, average="macro"),
        "mcc": matthews_corrcoef(yt, yp),
        "auc": roc_auc_score(ybin, y_prob, average="macro"),
    }


def evaluate_under_attack(model, X, y, eps):            # original function (PGD, alpha=0.005, 3 steps)
    X_adv = pgd_batch_tf(model, X[:1000], y[:1000], eps=eps)
    return accuracy_score(np.argmax(y[:1000], 1), np.argmax(model.predict(X_adv, verbose=0), 1))


def _cos(a, b):
    return float(np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b) + 1e-12))


# ---------------- dataset statistics (Reviewer 1 c2-3, Reviewer 2 c3) ----------------
def save_dataset_stats(parts):
    ytr, yte = np.argmax(y_train, 1), np.argmax(y_test, 1)
    rows = [{"class": CLASSES[k], "selected": int((ytr == k).sum() + (yte == k).sum()),
             "train": int((ytr == k).sum()), "test": int((yte == k).sum())} for k in range(n_classes)]
    pd.DataFrame(rows).to_csv(os.path.join(OUTPUT_DIR, "dataset_class_counts.csv"), index=False)
    dist = pd.DataFrame([[int((ytr[p] == k).sum()) for k in range(n_classes)] for p in parts],
                        columns=CLASSES, index=[f"Client {i+1}" for i in range(N_CLIENTS)])
    dist["total"] = dist.sum(1)
    dist.to_csv(os.path.join(OUTPUT_DIR, "client_class_distribution.csv"))
    info = {"records_after_dropna": int(N_AFTER_DROPNA), "records_selected": int(len(X)),
            "n_features": int(input_dim), "train": int(len(X_train)), "test": int(len(X_test)),
            "n_clients": N_CLIENTS, "malicious_clients": [m + 1 for m in MALICIOUS],
            "rounds": ROUNDS, "local_epochs": LOCAL_EPOCHS, "batch_size": BATCH_SIZE, "lr": LEARNING_RATE,
            "hardware": platform.processor() or platform.machine(), "python": platform.python_version(),
            "tensorflow": tf.__version__,
            "ram_GB": (psutil.virtual_memory().total / 1e9) if psutil else None}
    json.dump(info, open(os.path.join(OUTPUT_DIR, "setup.json"), "w"), indent=2, default=str)


# ---------------- one fresh, identical start for every method ----------------
def fresh_start():
    tf.keras.backend.clear_session()
    random.seed(SEED); np.random.seed(SEED); tf.random.set_seed(SEED)
    trust_rnn = build_trust_rnn()
    idx = np.arange(len(X_train))
    np.random.shuffle(idx)
    parts = np.array_split(idx, N_CLIENTS)
    clients = [Client(i, X_train[p], y_train[p], lambda: build_model(input_dim, n_classes), n_classes)
               for i, p in enumerate(parts)]
    global_model = build_model(input_dim, n_classes)
    return trust_rnn, parts, clients, global_model


# ---------------- server-side aggregation of each method ----------------
def agg_hybat(updates, st, ctx):
    """Original notebook aggregation with FIX 1 and FIX 3 (FIX 2 is inside NE_AGVO)."""
    trust_rnn, global_model, N = ctx["trust_rnn"], ctx["global_model"], N_CLIENTS
    behaviors = np.array(ctx["behaviors"]).reshape(N, 1, 3)
    A0 = build_adj_matrix(updates)                                         # FIX 1: consensus target
    consensus = np.array([(1 + (A0[i].sum() - A0[i, i]) / (N - 1)) / 2 for i in range(N)]).reshape(N, 1)
    trust_rnn.fit(behaviors, consensus, epochs=1, verbose=0)
    rnn_trust = trust_rnn.predict(behaviors, verbose=0).flatten()
    uncertainty = mc_dropout_uncertainty(global_model, X_train[:500])
    unc_score = 1 - (uncertainty.mean() / (uncertainty.max() + 1e-8))
    rnn_trust_u = rnn_trust * unc_score
    A = build_adj_matrix(updates)
    gnn_trust = A @ rnn_trust_u
    gnn_trust = (gnn_trust - gnn_trust.min()) / (gnn_trust.max() - gnn_trust.min() + 1e-8)   # FIX 3
    rl_w = rl_weight_policy(gnn_trust, updates)
    evo_w, fitnes = NE_AGVO(updates, gnn_trust)
    weights = 0.5 * rl_w + 0.5 * evo_w
    weights = weights / weights.sum()
    agg = np.sum([weights[i] * updates[i] for i in range(N)], axis=0)
    st.setdefault("trust", []).append(gnn_trust.copy())
    st.setdefault("rnn_trust", []).append(rnn_trust.copy())
    st.setdefault("unc_score", []).append(float(unc_score))
    st.setdefault("weights", []).append(weights.copy())
    st.setdefault("rl_w", []).append(rl_w.copy())
    st.setdefault("evo_w", []).append(evo_w.copy())
    st.setdefault("fitness", []).append(np.array(fitnes, dtype=float))
    st.setdefault("adj_mean", []).append(A.mean(1))
    return agg


def agg_trust_fedgnn(updates, st, ctx):
    """Trust-FedGNN [15] (Reis, 2026, Sec. 3-4): d_i = ||w_i - w|| / ||w||, phi = exp(-d),
    psi = min-max normalised accuracy of w_i on a server reference set, R~ = b1*phi + b2*psi,
    R = clip(min-max(R~), 0, 1), trust T <- a*T + (1-a)*R (T0 = 0.5, a = 0.8, b1 = 2.0, b2 = 1.2),
    aggregation weights = T / sum(T). Min and max are taken over the clients of the current round."""
    U = np.stack(updates); g = ctx["global_flat"]; n = len(U)
    evalm, shapes, sizes = ctx["evalm"], ctx["shapes"], ctx["sizes"]
    Xr, yr = X_train[:REF_SIZE], np.argmax(y_train[:REF_SIZE], 1)
    d = np.array([np.linalg.norm(u) / (np.linalg.norm(g) + 1e-12) for u in U])
    acc = []
    for u in U:
        evalm.set_weights(unflatten_weights(g + u, shapes, sizes))
        acc.append(accuracy_score(yr, np.argmax(evalm.predict(Xr, batch_size=256, verbose=0), 1)))
    acc = np.array(acc)
    if "tau" not in st:
        st["tau"] = np.full(n, TFG_T0)
    psi = (acc - acc.min()) / (acc.max() - acc.min() + 1e-12)            # validation term
    R_raw = TFG_B1 * np.exp(-d) + TFG_B2 * psi                            # raw reliability
    R = np.clip((R_raw - R_raw.min()) / (R_raw.max() - R_raw.min() + 1e-12), 0, 1)   # min-max + clip
    st["tau"] = TFG_ALPHA * st["tau"] + (1 - TFG_ALPHA) * R
    st.setdefault("ref_acc", []).append(acc.copy())
    w = st["tau"] / st["tau"].sum()
    st.setdefault("trust", []).append(st["tau"].copy())
    st.setdefault("weights", []).append(w.copy())
    return (w[:, None] * U).sum(0)


def agg_hypertrust_fog(updates, st, ctx):
    """HyperTrust-Fog [16], TAFA: tau <- (1-eta)*tau + eta*f, f = cosine(local update, previous global
    update) mapped to [0,1]; C = mean cosine to the other clients (group context) mapped to [0,1];
    R = participation reliability (all clients participate -> 1); gamma = l1*tau + l2*R + l3*C;
    weights ~ n_i * gamma_i. Initial trust ~ U[0.4, 1.0]."""
    U = np.stack(updates); n = len(U); n_samples = ctx["n_samples"]
    if "tau" not in st:
        st["tau"] = np.random.RandomState(SEED).uniform(0.4, 1.0, n)
    ref = st.get("prev_global", U.mean(0))
    f = np.array([(1 + _cos(u, ref)) / 2 for u in U])
    st["tau"] = (1 - HTF_ETA) * st["tau"] + HTF_ETA * f
    C = np.array([(1 + np.mean([_cos(U[i], U[j]) for j in range(n) if j != i])) / 2 for i in range(n)])
    gamma = HTF_L1 * st["tau"] + HTF_L2 * 1.0 + HTF_L3 * C
    w = n_samples * gamma; w = w / w.sum()
    agg = (w[:, None] * U).sum(0)
    st["prev_global"] = agg
    st.setdefault("trust", []).append(gamma.copy())
    st.setdefault("weights", []).append(w.copy())
    return agg


AGG = {"HybAT-RGNN": agg_hybat, "Trust-FedGNN": agg_trust_fedgnn, "HyperTrust-Fog": agg_hypertrust_fog}


# ---------------- final evaluation of a trained global model ----------------
def final_evaluation(name, model, out, n_params, round_times):
    tr_p = model.predict(X_train, batch_size=256, verbose=0)
    te_p = model.predict(X_test, batch_size=256, verbose=0)
    np.savez_compressed(os.path.join(out, "probabilities.npz"), train=tr_p, test=te_p,
                        y_train=np.argmax(y_train, 1), y_test=np.argmax(y_test, 1))
    for split, y, p in (("train", y_train, tr_p), ("test", y_test, te_p)):
        yt, yp = np.argmax(y, 1), np.argmax(p, 1)
        pd.DataFrame(confusion_matrix(yt, yp, labels=range(n_classes)), index=CLASSES, columns=CLASSES) \
            .to_csv(os.path.join(out, f"confusion_{split}.csv"))
        rep = pd.DataFrame(classification_report(yt, yp, labels=range(n_classes), target_names=CLASSES,
                                                 output_dict=True, zero_division=0)).T
        yb = label_binarize(yt, classes=np.arange(n_classes))
        rep["AP"] = np.nan; rep["AUC"] = np.nan
        rep.loc[CLASSES, "AP"] = [average_precision_score(yb[:, k], p[:, k]) for k in range(n_classes)]
        rep.loc[CLASSES, "AUC"] = [roc_auc_score(yb[:, k], p[:, k]) for k in range(n_classes)]
        rep.to_csv(os.path.join(out, f"per_class_{split}.csv"))
    # robustness: original configuration (PGD, L-inf, alpha=0.005, 3 steps, first 1000 test samples)
    rob = []
    for e in EPS_VALS:
        acc_orig = evaluate_under_attack(model, X_test, y_test, e)
        Xa = pgd_batch_tf(model, X_test[:1000], y_test[:1000], eps=e, alpha=2.5 * e / 10, steps=10) if e > 0 else X_test[:1000]
        acc_10 = accuracy_score(np.argmax(y_test[:1000], 1), np.argmax(model.predict(Xa, verbose=0), 1))
        rob.append({"epsilon": e, "acc_pgd_3steps_alpha0.005": acc_orig, "acc_pgd_10steps_alpha2.5eps/10": acc_10})
    pd.DataFrame(rob).to_csv(os.path.join(out, "adversarial_robustness.csv"), index=False)
    # cost
    t0 = time.perf_counter(); model.predict(X_test, batch_size=256, verbose=0)
    lat_batch = (time.perf_counter() - t0) / len(X_test) * 1000
    one = X_test[:1]; model.predict(one, verbose=0); t0 = time.perf_counter()
    for _ in range(100): model(one, training=False)
    lat_single = (time.perf_counter() - t0) / 100 * 1000
    model.save(os.path.join(out, "final_model.h5"))
    cost = {"method": name, "params": int(n_params), "model_size_MB_float32": n_params * 4 / 2**20,
            "model_file_MB": os.path.getsize(os.path.join(out, "final_model.h5")) / 2**20,
            "comm_per_round_MB_all_clients_up+down": 2 * N_CLIENTS * n_params * 4 / 2**20,
            "comm_total_MB": ROUNDS * 2 * N_CLIENTS * n_params * 4 / 2**20,
            "train_time_total_s": float(np.sum(round_times)), "train_time_per_round_s": float(np.mean(round_times)),
            "inference_ms_per_sample_batch256": lat_batch, "inference_ms_single_sample": lat_single,
            "peak_rss_MB": float(np.nanmax(round_times_rss)) if round_times_rss else float("nan")}
    return cost


# ---------------- run one method (with per-round checkpoint) ----------------
round_times_rss = []


def run_method(name):
    global round_times_rss
    out = os.path.join(OUTPUT_DIR, name); os.makedirs(out, exist_ok=True)
    if os.path.exists(os.path.join(out, "DONE")):
        print(f"[{name}] already finished - skipped"); return
    trust_rnn, parts, clients, global_model = fresh_start()
    if name == METHODS[0] or not os.path.exists(os.path.join(OUTPUT_DIR, "setup.json")):
        save_dataset_stats(parts)
    global_flat, shapes, sizes = flatten_weights(global_model.get_weights())
    n_params = global_flat.size
    ctx = {"trust_rnn": trust_rnn, "global_model": global_model, "shapes": shapes, "sizes": sizes,
           "n_samples": np.array([len(p) for p in parts], float),
           "evalm": build_model(input_dim, n_classes) if name == "Trust-FedGNN" else None}
    history, st, rt, at, start = [], {}, [], [], 1
    ck = os.path.join(out, "checkpoint.pkl")
    if os.path.exists(ck):
        s = pickle.load(open(ck, "rb"))
        global_flat, history, st, rt, at, round_times_rss = s["g"], s["h"], s["st"], s["rt"], s["at"], s["rss"]
        for c, hcl in zip(clients, s["chist"]): c.history = hcl
        if s.get("trnn") is not None:
            trust_rnn(np.zeros((N_CLIENTS, 1, 3), np.float32)); trust_rnn.set_weights(s["trnn"])
        np.random.set_state(s["np"]); random.setstate(s["py"])
        global_model.set_weights(unflatten_weights(global_flat, shapes, sizes))
        start = len(history) + 1
        print(f"[{name}] resuming from round {start}")
    else:
        round_times_rss = []
    print(f"\n========== {name}: federated training ({ROUNDS} rounds) ==========")
    for r in range(start, ROUNDS + 1):
        t_round = time.perf_counter()
        updates, behaviors = [], []
        for c in clients:
            delta = c.local_train(global_flat.copy(), shapes, sizes)
            if c.cid in MALICIOUS:
                delta *= -1                                  # sign-flip attack (original)
            updates.append(delta); behaviors.append(c.history[-1])
        ctx.update(global_flat=global_flat, behaviors=behaviors)
        t_agg = time.perf_counter()
        agg = AGG[name](updates, st, ctx)
        at.append(time.perf_counter() - t_agg)
        global_flat = global_flat + agg
        global_model.set_weights(unflatten_weights(global_flat, shapes, sizes))
        train_probs = global_model.predict(X_train, batch_size=256, verbose=0)
        test_probs = global_model.predict(X_test, batch_size=256, verbose=0)
        trm, tem = compute_metrics(y_train, train_probs), compute_metrics(y_test, test_probs)
        rt.append(time.perf_counter() - t_round); round_times_rss.append(rss_mb())
        history.append({"round": r, **{f"train_{k}": v for k, v in trm.items()},
                        **{f"test_{k}": v for k, v in tem.items()},
                        "round_time_s": rt[-1], "aggregation_time_s": at[-1], "rss_MB": round_times_rss[-1]})
        print(f"  [{name}] round {r:2d}/{ROUNDS}  test acc={tem['accuracy']:.4f}  f1={tem['f1']:.4f}  {rt[-1]:.0f}s")
        pickle.dump({"g": global_flat, "h": history, "st": st, "rt": rt, "at": at, "rss": round_times_rss,
                     "chist": [c.history for c in clients],
                     "trnn": trust_rnn.get_weights() if trust_rnn.built else None,
                     "np": np.random.get_state(), "py": random.getstate()}, open(ck, "wb"))
    # ---- save logs ----
    pd.DataFrame(history).to_csv(os.path.join(out, "history.csv"), index=False)
    cols = [f"Client {i+1}" for i in range(N_CLIENTS)]
    for key in ("trust", "rnn_trust", "weights", "rl_w", "evo_w", "adj_mean", "ref_acc"):
        if key in st:
            pd.DataFrame(np.array(st[key]), columns=cols, index=range(1, len(st[key]) + 1)) \
                .rename_axis("round").to_csv(os.path.join(out, f"{key}_log.csv"))
    if "fitness" in st:
        F = np.array(st["fitness"])
        pd.DataFrame({"round": range(1, len(F) + 1), "mean": F.mean(1), "std": F.std(1), "first": F[:, 0],
                      "last": F[:, -1], "max": F.max(1)}).to_csv(os.path.join(out, "agvo_fitness.csv"), index=False)
        pd.DataFrame(F, index=range(1, len(F) + 1)).rename_axis("round").to_csv(os.path.join(out, "agvo_fitness_all_iterations.csv"))
    if "unc_score" in st:
        pd.DataFrame({"round": range(1, len(st["unc_score"]) + 1), "unc_score": st["unc_score"]}) \
            .to_csv(os.path.join(out, "uncertainty_score.csv"), index=False)
    cost = final_evaluation(name, global_model, out, n_params, rt)
    json.dump(cost, open(os.path.join(out, "cost.json"), "w"), indent=2, default=str)
    open(os.path.join(out, "DONE"), "w").write("ok")
    print(f"[{name}] finished. final test accuracy = {history[-1]['test_accuracy']*100:.2f}%")


# ---------------- summary tables over all finished methods ----------------
def summary():
    done = [m for m in METHODS if os.path.exists(os.path.join(OUTPUT_DIR, m, "DONE"))]
    if not done:
        return
    RR = [r for r in (5, 10, 15, 20) if r <= ROUNDS] or [ROUNDS]
    H = {m: pd.read_csv(os.path.join(OUTPUT_DIR, m, "history.csv")) for m in done}
    for k in ("accuracy", "precision", "recall", "f1", "mcc", "auc"):
        t = pd.DataFrame({m: [H[m].loc[H[m]["round"] == r, f"test_{k}"].iloc[0] * 100 for r in RR]
                          for m in done}, index=[f"Round-{r}" for r in RR]).T
        t.to_csv(os.path.join(OUTPUT_DIR, f"table_{k}_rounds.csv"), float_format="%.2f")
    pd.DataFrame([json.load(open(os.path.join(OUTPUT_DIR, m, "cost.json"))) for m in done]) \
        .to_csv(os.path.join(OUTPUT_DIR, "table_cost.csv"), index=False)
    print("\n================ SUMMARY (test set, final round) ================")
    for m in done:
        h = H[m].iloc[-1]
        print(f"{m:15s} acc={h.test_accuracy*100:6.2f}  prec={h.test_precision*100:6.2f}  "
              f"rec={h.test_recall*100:6.2f}  f1={h.test_f1*100:6.2f}")


if __name__ == "__main__":
    todo = [a for a in sys.argv[1:] if a in METHODS] or METHODS
    T0 = time.time()
    for m in todo:
        run_method(m)
        summary()
    print(f"\nAll done in {(time.time() - T0) / 3600:.2f} h.  Results in: {os.path.abspath(OUTPUT_DIR)}")
