# HybAT-RGNN — Trust-Aware Federated Cyberthreat Detection in Edge-IIoT Networks

Code and results of the paper *"Trust-Aware Federated Cyberthreat Detection in Edge-IIoT Networks via Hybrid
Adversarial Deep Learning and Robust RNN–GNN Aggregation"* (revised version).

## Files
| File | Content |
|---|---|
| `hybat_rgnn.py` | Proposed method HybAT-RGNN (training, trust estimation, NE-AGVO aggregation, evaluation) |
| `baselines.py` | Trust-FedGNN [15] and HyperTrust-Fog [16], re-implemented under the identical setup |
| `redraw_figures.py` | Draws Figures 3–16 from the saved results |
| `results/` | All logs and results used in the paper (one folder per method) |
| `figures/` | Figures 3–16 |

## Data
Edge-IIoTset, file `DNN-EdgeIIoT-dataset.csv` (2,219,201 records). The first 5,000 records of each of the
12 classes are used (Fingerprinting: 1,001 available) → 56,001 records, 60 features, stratified 70:30 split
(39,200 train / 16,801 test). Place the CSV next to the scripts.

## Setup (identical for all methods)
12 IID clients (3,266–3,267 samples each), clients 1 and 2 malicious (sign-flipping of their updates),
20 communication rounds, 1 local epoch, batch size 64, Adam (1e-3), seed 42, local training on clean +
PGD (ε = 0.01, α = 0.005, 3 steps, L∞) + FGSM (ε = 0.01) samples. Only the server-side aggregation differs.

## Run
```
pip install tensorflow pandas scikit-learn matplotlib seaborn tqdm psutil
python hybat_rgnn.py          # ~1.8 h on an Intel Core i5-10th gen CPU
python baselines.py           # ~1.8 h per method
python redraw_figures.py tnr
```
`--quick` runs a 3-minute test (2 rounds, 300 records per class). An interrupted run resumes from its last round.

## Main results (test set, round 20)
| Method | accuracy | precision | recall | f1 | mcc | auc |
|---|---|---|---|---|---|---|
| HybAT-RGNN | 97.24 | 97.62 | 96.41 | 96.82 | 97.01 | 99.95 |
| Trust-FedGNN | 97.10 | 97.45 | 96.28 | 96.66 | 96.86 | 99.93 |
| HyperTrust-Fog | 96.85 | 97.28 | 96.04 | 96.41 | 96.59 | 99.91 |

| Accuracy (%) | Round-5 | Round-10 | Round-15 | Round-20 |
|---|---|---|---|---|
| HybAT-RGNN | 81.07 | 95.67 | 96.63 | 97.24 |
| Trust-FedGNN | 67.17 | 93.89 | 96.29 | 97.10 |
| HyperTrust-Fog | 64.36 | 93.64 | 96.11 | 96.85 |

Accuracy (%) under PGD attack (10 steps, α = 2.5ε/10, first 1,000 test samples):

| Method | ε = 0.0 | ε = 0.005 | ε = 0.01 | ε = 0.02 | ε = 0.03 |
|---|---|---|---|---|---|
| HybAT-RGNN | 97.0 | 96.6 | 96.0 | 95.4 | 91.3 |
| Trust-FedGNN | 96.9 | 96.4 | 96.2 | 94.3 | 89.6 |
| HyperTrust-Fog | 96.8 | 96.4 | 95.8 | 93.2 | 89.6 |

Detailed logs: `results/<method>/history.csv` (all rounds), `trust_log.csv`, `weights_log.csv`,
`agvo_fitness*.csv`, `confusion_*.csv`, `per_class_*.csv` (with AP and AUC), `cost.json`.
