# -*- coding: utf-8 -*-
"""
redraw_figures.py -- draws Figures 3-16 of the paper from the saved results (no retraining, no TensorFlow).
Run after hybat_rgnn.py and baselines.py:   python redraw_figures.py tnr      (Times New Roman)
Figures: folder figures
"""
import io, os, sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sbn
from sklearn.preprocessing import label_binarize
from sklearn.metrics import (confusion_matrix, roc_curve, precision_recall_curve,
                             average_precision_score, accuracy_score)

STYLE = sys.argv[1] if len(sys.argv) > 1 else "original"
OUT = os.environ.get("OUT", "figures")
os.makedirs(OUT, exist_ok=True)
MONO = "Times New Roman" if STYLE == "tnr" else "Consolas"
SANS = "Times New Roman" if STYLE == "tnr" else "DejaVu Sans"


def save(fig, name):
    for ext in ("png", "svg", "pdf"):
        fig.savefig(os.path.join(OUT, f"{name}.{ext}"), dpi=300 if ext == "png" else None)
    plt.close(fig)


def mono():
    plt.rcParams.update(plt.rcParamsDefault)
    plt.rcParams["font.family"] = [MONO, "DejaVu Sans Mono"] if MONO == "Consolas" else [MONO, "Liberation Serif", "DejaVu Serif"]
    plt.rcParams["svg.fonttype"] = "none"
    plt.rcParams["pdf.fonttype"] = 42


def sans():
    plt.rcParams.update(plt.rcParamsDefault)
    plt.rcParams["font.family"] = [SANS, "Liberation Serif", "DejaVu Serif"] if SANS == "Times New Roman" else SANS
    plt.rcParams["font.weight"] = "bold"
    plt.rcParams["axes.labelweight"] = "bold"
    plt.rcParams["svg.fonttype"] = "none"
    plt.rcParams["pdf.fonttype"] = 42


# ------------------------------------------------------------------ data (saved predictions, no TF needed)
RES = os.environ.get("RES", "results")
H = os.path.join(RES, "HybAT-RGNN")
CLASSES = ["Normal", "DDoS-UDP", "DDoS-ICMP", "SQL injection", "DDoS-TCP", "Password", "DDoS-HTTP",
           "Uploading", "Backdoor", "XSS", "Ransomware", "Fingerprinting"]
NC = len(CLASSES)
z = np.load(os.path.join(H, "probabilities.npz"))
p_tr, p_te, y_tr, y_te = z["train"], z["test"], z["y_train"], z["y_test"]
print(f"      test accuracy from saved predictions: {accuracy_score(y_te, p_te.argmax(1)) * 100:.2f}%")
print("[2/3] Drawing Figures 3-11 ...")
# ------------------------------------------------------------------ Figure 3
mono()
rob = pd.read_csv(os.path.join(H, "adversarial_robustness.csv"))
rob["accuracy"] = rob["acc_pgd_3steps_alpha0.005"]
fig = plt.figure(figsize=(6, 4)); ax = fig.gca()
ax.plot(rob["epsilon"], rob["accuracy"], marker="o")
ax.set_title("Adversarial Robustness Curve"); ax.set_xlabel("PGD Attack Strength (ε)"); ax.set_ylabel("Accuracy")
ax.grid(True); fig.tight_layout(); save(fig, "fig03_adversarial_robustness")

# ------------------------------------------------------------------ Figure 4
fit = pd.read_csv(os.path.join(H, "agvo_fitness.csv"))
fit["best_fitness_final"] = fit["last"]
fig = plt.figure(figsize=(6, 4)); ax = fig.gca()
ax.plot(fit["round"], fit["best_fitness_final"])
ax.set_title("Metaheuristic Convergence"); ax.set_xlabel("Federated Round"); ax.set_ylabel("AGVO Fitness")
ax.grid(True); fig.tight_layout(); save(fig, "fig04_agvo_convergence")

# ------------------------------------------------------------------ Figure 5
tr_df = pd.read_csv(os.path.join(H, "trust_log.csv"), index_col=0)
tr, rounds_ = tr_df.values, tr_df.index.values
fig = plt.figure(figsize=(6, 4)); ax = fig.gca()
cols = sbn.color_palette("husl", tr.shape[1])
for i in range(tr.shape[1]):
    ax.plot(rounds_, tr[:, i], label=f"Client {i + 1}" + (" (M)" if i in (0, 1) else ""), color=cols[i])
ax.set_title("GNN-Based Client Trust Evolution"); ax.set_xlabel("Federated Round"); ax.set_ylabel("Trust Score")
ax.legend(ncol=3); ax.grid(True); fig.tight_layout(); save(fig, "fig05_client_trust")


# ------------------------------------------------------------------ Figures 6-7
def plot_cm(y, pred, name, title):
    cm = confusion_matrix(y, pred, labels=range(NC))
    fig = plt.figure(figsize=(6, 6)); ax = fig.add_subplot(111)
    sbn.heatmap(cm, annot=True, fmt="d", cmap="Dark2", ax=ax, xticklabels=CLASSES, yticklabels=CLASSES,
                square=True, cbar=False, annot_kws={"size": 7})
    ax.set_title(title); ax.set_xlabel("Predicted"); ax.set_ylabel("True")
    fig.tight_layout(); save(fig, name)


plot_cm(y_te, p_te.argmax(1), "fig06_confusion_test", "Test Confusion Matrix")
plot_cm(y_tr, p_tr.argmax(1), "fig07_confusion_train", "Train Confusion Matrix")


# ------------------------------------------------------------------ Figures 8-9
def plot_pr(y, prob, name, title):
    cols = sbn.color_palette("Dark2", NC)
    yb = label_binarize(y, classes=np.arange(NC))
    fig = plt.figure(figsize=(6, 5)); ax = fig.add_subplot(111)
    lowest = 1.0
    for i in range(NC):
        pr, rc, _ = precision_recall_curve(yb[:, i], prob[:, i])
        ap = average_precision_score(yb[:, i], prob[:, i])
        ax.plot(rc, pr, label=f"{CLASSES[i]} (AP={ap:.3f})", color=cols[i])
        lowest = min(lowest, pr[rc >= 0.5].min())
    ax.grid(True); ax.set_title(title); ax.set_xlabel("Recall"); ax.set_ylabel("Precision")
    ax.set_xlim([0.5, 1.015]); ax.set_ylim([np.floor(lowest * 10) / 10, 1.02])
    ax.legend(ncol=1, fontsize=7); fig.tight_layout(); save(fig, name)


plot_pr(y_te, p_te, "fig08_pr_test", "Test PR Curve")
plot_pr(y_tr, p_tr, "fig09_pr_train", "Train PR Curve")


# ------------------------------------------------------------------ Figures 10-11
def plot_roc(y, prob, name, title):
    cols = sbn.color_palette("Dark2", NC)
    yb = label_binarize(y, classes=np.arange(NC))
    fig = plt.figure(figsize=(6, 4)); ax = fig.add_subplot(111)
    lowest = 1.0
    for i in range(NC):
        fpr, tpr, _ = roc_curve(yb[:, i], prob[:, i])
        ax.plot(fpr, tpr, label=f"{CLASSES[i]}", color=cols[i])
        lowest = min(lowest, np.interp(0.0225, fpr, tpr))
    ax.grid(True); ax.plot([0, 1], [0, 1], "k--")
    ax.set_title(title); ax.set_xlabel("FPR"); ax.set_ylabel("TPR")
    ax.set_xlim([-0.0015, 0.0225]); ax.set_ylim([max(0.0, np.floor(lowest * 10) / 10 - 0.1), 1.02])
    ax.legend(ncol=2, fontsize=7); fig.tight_layout(); save(fig, name)


plot_roc(y_te, p_te, "fig10_roc_test", "Test ROC Curve")
plot_roc(y_tr, p_tr, "fig11_roc_train", "Train ROC Curve")

# ------------------------------------------------------------------ Figures 12-16
print("[3/3] Drawing Figures 12-16 ...")
sans()
ORDER = ["Trust-FedGNN", "HyperTrust-Fog", "HybAT-RGNN"]
C_RND = {"Trust-FedGNN": "#1a1a1a", "HyperTrust-Fog": "#17a96e", "HybAT-RGNN": "#ffc61e"}
C_ALL = {"Trust-FedGNN": "#3182bd", "HyperTrust-Fog": "#1a8c1a", "HybAT-RGNN": "#9b7de0"}


def style(ax, ylab, ticks, loc="upper right"):
    ax.set_ylabel(ylab, fontsize=12, fontweight="bold")
    ax.set_xticks(range(len(ticks))); ax.set_xticklabels(ticks, fontweight="bold", fontsize=11)
    for t in ax.get_yticklabels(): t.set_fontweight("bold"); t.set_fontsize(11)
    ax.minorticks_on(); ax.tick_params(axis="x", which="minor", bottom=False)
    ax.grid(True, which="both", linestyle=":", linewidth=0.6, alpha=0.6)
    ax.set_xlim(0, len(ticks) - 1)
    ax.legend(ncol=2, loc=loc, prop={"weight": "bold", "size": 11})


def comparison(values, ylab, ticks, colors, marker, name, loc="upper right"):
    fig = plt.figure(figsize=(6.4, 4.8)); ax = fig.gca()
    allv = np.concatenate([values[m] for m in ORDER])
    lo = np.floor(allv.min() - 1); hi = np.ceil(allv.max() + 1)
    x = np.arange(len(ticks))
    for m in ORDER:
        ax.fill_between(x, lo, values[m], color=colors[m], alpha=0.06)
    for m in ORDER:
        ax.plot(x, values[m], color=colors[m], linewidth=3, marker=marker, markersize=8 if marker == "o" else 9,
                markerfacecolor="white", markeredgecolor="black", label=m)
    ax.set_ylim(lo, hi)
    style(ax, ylab, ticks, loc); fig.tight_layout(); save(fig, name)


HIST = {m: pd.read_csv(os.path.join(RES, m, "history.csv")) for m in ORDER}
RR = [5, 10, 15, 20]
for n, (metric, lab) in zip(range(12, 16), (("accuracy", "Accuracy (%)"), ("precision", "Precision (%)"),
                                            ("recall", "Recall (%)"), ("f1", "F1-Score (%)"))):
    vals = {m: np.array([HIST[m].loc[HIST[m]["round"] == r, f"test_{metric}"].iloc[0] * 100 for r in RR]) for m in ORDER}
    comparison(vals, lab, [f"Round-{r}" for r in RR], C_RND, "o", f"fig{n}_comparison_{metric}", loc="lower right")

vals = {m: np.array([HIST[m][f"test_{k}"].iloc[-1] * 100 for k in ("accuracy", "precision", "recall", "f1")]) for m in ORDER}
comparison(vals, "Values (%)", ["Accuracy", "Precision", "Recall", "F1-score"], C_ALL, "*",
           "fig16_comparison_overall_final")
print("Done. Figures saved in:", os.path.abspath(OUT))
